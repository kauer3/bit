using Newtonsoft.Json;
using PlayingCards;
using System.Runtime.Serialization.Formatters.Binary;

namespace Card_Dealer
{
    public partial class Form1 : Form
    {
        private Deck deck;
        List<Image> images = new List<Image>();

        const int HAND_SIZE = 13;
        const int CARD_WIDTH = 75;
        const int CARD_HEIGHT = 108;

        List<PlayingCard> firstHand;
        List<PlayingCard> secondHand;
        List<PlayingCard> thirdHand;
        List<PlayingCard> fourthHand;
        PictureBox[] cardImages;

        int selectedHand = 0;

        public Form1()
        {
            InitializeComponent();

            deck = new Deck();
            cardImages = new PictureBox[52];

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HandleImages();
            DealCards();

            comboBox1.SelectedIndex = 0;
        }

        private void DealButton_Click(Object sender, EventArgs e)
        {
            deck = new Deck();
            images.Clear();
            HandleImages();
            DealCards();
            GetSelectedHand(selectedHand);
        }

        private void SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox cb = (ComboBox)sender;
            selectedHand = cb.SelectedIndex;
            GetSelectedHand(selectedHand);
        }

        private void GetSelectedHand(int hand)
        {
            switch (hand)
            {
                case 0:
                    DisplayHand(firstHand);
                    break;
                case 1:
                    DisplayHand(secondHand);
                    break;
                case 2:
                    DisplayHand(thirdHand);
                    break;
                case 3:
                    DisplayHand(fourthHand);
                    break;
            }
        }

        private void DisplayHand(List<PlayingCard> hand)
        {
            for (int i = 0; i < hand.Count; i++)
            {
                cardImages[i].Image = hand[i].GetImage();

                int row = i / HAND_SIZE;
                int col = i % HAND_SIZE;
                cardImages[i].Location = new Point(10 + col * CARD_WIDTH, 45 + row * CARD_HEIGHT);
                cardImages[i].Size = (new Size(CARD_WIDTH, CARD_HEIGHT));
                cardImages[i].SizeMode = PictureBoxSizeMode.StretchImage;

                Controls.Add(cardImages[i]);
            }
        }

        private void HandleImages()
        {
            for (int i = 0; i < 52 - 1; i++)
            {
                if (cardImages[i] != null)
                {
                    cardImages[i].Dispose();
                }
                cardImages[i] = new PictureBox();
            }

            for (int i = 0; i < imageList1.Images.Count - 1; i++)
            {
                images.Add(imageList1.Images[i]);
            }

            deck.AssigImages(images, imageList1.Images[52]);
        }

        private void DealCards()
        {
            deck.Shuffle();

            firstHand = DealHand();
            secondHand = DealHand();
            thirdHand = DealHand();
            fourthHand = DealHand();
        }

        private List<PlayingCard> DealHand()
        {
            PlayingCard? card;
            List<PlayingCard> hand = new List<PlayingCard>();
            
            for (int i = 0; i < HAND_SIZE; i++)
            {
                card = deck.DealTopCard();
                hand.Add(card);
            }

            return hand;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.ShowDialog();

            if (saveFileDialog.FileName != "")
            {

                List<List<PlayingCard>> hands = new List<List<PlayingCard>>();

#pragma warning disable SYSLIB0011 // Type or member is obsolete
                BinaryFormatter formatter = new BinaryFormatter();
#pragma warning restore SYSLIB0011 // Type or member is obsolete

                using (FileStream stream = new FileStream(saveFileDialog.FileName, FileMode.Create))
                {
                    formatter.Serialize(stream, hands);
                }
            }
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();

            if (openFileDialog.FileName != "")
            {
#pragma warning disable SYSLIB0011 // Type or member is obsolete
                BinaryFormatter formatter = new BinaryFormatter();
#pragma warning restore SYSLIB0011 // Type or member is obsolete
                using (FileStream stream = new FileStream(openFileDialog.FileName, FileMode.Open))
                {
                    ListOfHands hands = (ListOfHands)formatter.Deserialize(stream);
                    firstHand = hands.firstHand;
                    secondHand = hands.secondHand;
                    thirdHand = hands.thirdHand;
                    fourthHand = hands.fourthHand;

                    if (selectedHand == 0)
                    {
                        DisplayHand(firstHand);
                    }
                    else
                    {
                        comboBox1.SelectedIndex = 0;
                    }
                }
            }
        }

        [Serializable]
        class ListOfHands
        {
            public List<PlayingCard> firstHand;
            public List<PlayingCard> secondHand;
            public List<PlayingCard> thirdHand;
            public List<PlayingCard> fourthHand;

            public ListOfHands(List<PlayingCard> firstHand, List<PlayingCard> secondHand, List<PlayingCard> thirdHand, List<PlayingCard> fourthHand)
            {
                this.firstHand = firstHand;
                this.secondHand = secondHand;
                this.thirdHand = thirdHand;
                this.fourthHand = fourthHand;
            }
        }
    }
}
