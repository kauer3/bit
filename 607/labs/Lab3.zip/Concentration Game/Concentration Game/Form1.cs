using PlayingCards;
using System.Windows.Forms;

namespace Concentration_Game
{
    public partial class Form1 : Form
    {
        const int NUM_CARDS = 32;
        const int NUM_COLS = 8;
        const int CARD_WIDTH = 75;
        const int CARD_HEIGHT = 108;
        Deck deck;
        PictureBox[] cardImages;
        List<Image> images = new List<Image>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            deck = new Deck(
                CardRank.Ace,
                CardRank.Two,
                CardRank.Three,
                CardRank.Four,
                CardRank.Five,
                CardRank.Six,
                CardRank.Seven,
                CardRank.Eight
            );

            cardImages = new PictureBox[NUM_CARDS];


            for (int i = 0; i < imageList1.Images.Count - 1; i++)
            {
                images.Add(imageList1.Images[i]);
            }

            deck.AssigImages(images, imageList1.Images[32]);

            deck.Shuffle();

            for (int i = 0; i < cardImages.Length; i++)
            {
                cardImages[i] = new PictureBox();
                PlayingCard card = deck.DealTopCard();
                card.IsFaceUp = false;
                cardImages[i].Image = card.GetImage();

                int row = i / NUM_COLS;
                int col = i % NUM_COLS;
                cardImages[i].Location = new Point(10 + col * CARD_WIDTH, 10 + row * CARD_HEIGHT);
                cardImages[i].Size = (new Size(CARD_WIDTH, CARD_HEIGHT));
                cardImages[i].SizeMode = PictureBoxSizeMode.StretchImage;

                cardImages[i].Click += Card_Click;
                cardImages[i].Tag = card;
                Controls.Add(cardImages[i]);
            }
        }

        private void Card_Click(object? sender, EventArgs e)
        {
            PictureBox box = sender as PictureBox;
            PlayingCard card = box.Tag as PlayingCard;
            card.Flip();
            box.Image = card.GetImage();
        }
    }
}
